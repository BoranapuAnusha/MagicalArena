package com.example.magical;
import java.util.Random;
class Player {
	private int health;
	private int strength;
	private int attack;
	private Random random;

	public Player(int health, int strength, int attack) {
		this.health = health;
		this.strength = strength;
		this.attack = attack;
		this.random = new Random();
	}

	public int getHealth() {
		return health;
	}

	public boolean isAlive() {
		return health > 0;
	}

	public int attack() {
		return random.nextInt(6) + 1;
	}

	public int defend() {
		return random.nextInt(6) + 1;
	}

	public void takeDamage(int damage) {
		health -= damage;
		if (health < 0) {
			health = 0;
		}
	}

	public int calculateAttackDamage(int roll) {
		return attack * roll;
	}

	public int calculateDefendStrength(int roll) {
		return strength * roll;
	}
}

class MagicalArena {
	private Player playerA;
	private Player playerB;
	private Random random;
	public MagicalArena(Player playerA, Player playerB) {
		this.playerA = playerA;
		this.playerB = playerB;
		this.random = new Random();
	}
	public void playGame() {
		while (playerA.isAlive() && playerB.isAlive()) {
			Player attacker, defender;
			if (playerA.getHealth() <= playerB.getHealth()) {
				attacker = playerA;
				defender = playerB;
			} else {
				attacker = playerB;
				defender = playerA;
			}
			int attackRoll = attacker.attack();
			int defendRoll = defender.defend();

			int attackDamage = attacker.calculateAttackDamage(attackRoll);
			int defendStrength = defender.calculateDefendStrength(defendRoll);

			int damageTaken = Math.max(attackDamage - defendStrength, 0);
			defender.takeDamage(damageTaken);
			System.out.println(attacker.getClass().getSimpleName() + " attacks with roll: " + attackRoll);
			System.out.println(defender.getClass().getSimpleName() + " defends with roll: " + defendRoll);
			System.out.println(attacker.getClass().getSimpleName() + " deals " + attackDamage + " damage");
			System.out.println(defender.getClass().getSimpleName() + " defends " + defendStrength + " damage");
			System.out.println(defender.getClass().getSimpleName() + "'s health: " + defender.getHealth());
			System.out.println();
		}
		if (playerA.isAlive()) {
			System.out.println("Player A wins!");
		} else {
			System.out.println("Player B wins!");
		}
	}
}

