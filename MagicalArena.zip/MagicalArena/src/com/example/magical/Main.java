package com.example.magical;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Player playerA = new Player(50, 5, 10);
        Player playerB = new Player(100, 10, 5);
        MagicalArena arena = new MagicalArena(playerA, playerB);
        arena.playGame();


	}

}
