package com.example.magical;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class MagicalArenaTest {
	@Test
	void testPlayGame() {
		Player playerA = new Player(50, 5, 10);
		Player playerB = new Player(100, 10, 5);
		MagicalArena arena = new MagicalArena(playerA, playerB);
		arena.playGame();
		assertTrue(!playerA.isAlive() || !playerB.isAlive()); // At least one player should be dead

	}

}
