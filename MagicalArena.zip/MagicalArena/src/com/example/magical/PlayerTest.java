package com.example.magical;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class PlayerTest {
	@Test
	void testTakeDamage() {
		Player player = new Player(100, 10, 5);
		player.takeDamage(20);
		assertEquals(80, player.getHealth());
	}
	@Test
	void testTakeDamageBelowZero() {
		Player player = new Player(30, 5, 5);
		player.takeDamage(40);
		assertEquals(0, player.getHealth());
	}
	@Test
	void testIsAlive() {
		Player player = new Player(50, 10, 5);
		assertTrue(player.isAlive());
		player.takeDamage(50);
		assertFalse(player.isAlive());
	}
}

